<?php get_header(); ?>

<?php if (have_posts()) : ?>
    <?php while (have_posts()) : the_post(); ?>
        <section class="hero">
            <div class="wrap">
                <div class="hero__medias">
                    <div class="hero__image">
                        <?php the_post_thumbnail(); ?>
                    </div>
                </div>
            </div>
        </section>

        <section class="grid section wrap">
            <h1 class="grid__title">
                <?php the_title(); ?>

                <?php if (get_field('cw4_acteur_oscar')): ?>
                    <small>🥇</small>
                <?php endif; ?>
            </h1>
            <div class="grid__content o-typography">
                <?php the_content(); ?>
            </div>
            <div class="grid__sidebar o-typography">
                <?php if (get_field('cw4_acteur_naissance')): ?>
                    <h3>Date de naissance</h3>
                    <p><?php the_field('cw4_acteur_naissance') ?></p>    
                <?php endif; ?>
                <?php if (get_field('cw4_acteur_nationalite')): ?>
                    <h3>Nationalité</h3>
                    <p><?php the_field('cw4_acteur_nationalite') ?></p>
                <?php endif; ?>

                <h3>Réseaux Sociaux</h3>
                <ul class="social">
                    <li>
                        <a href="https://linkedin.com" target="_blank">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                    </li>
                    <li>
                        <a href="https://instagram.com" target="_blank">
                            <i class="fab fa-instagram"></i>
                        </a>
                    </li>
                    <li>
                        <a href="https://facebook.com" target="_blank">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                    </li>
                    <li>
                        <a href="https://twitter.com" target="_blank">
                            <i class="fab fa-twitter"></i>
                        </a>
                    </li>
                </ul>

                <?php if (get_field('cw4_acteur_imdb')): ?>
                    <h3>Page IMDB</h3>
                    <a href="<?php the_field('cw4_acteur_imdb') ?>" target="_blank" rel="noopener">
                        En savoir plus
                    </a>
                <?php endif; ?>
            </div>
        </section>
    <?php endwhile; ?>
<?php endif; ?>

<?php get_footer(); ?>