<?php get_header(); ?>

<section class="section wrap">
    <?php if (have_posts()) : ?>
        <h1><?php post_type_archive_title(); ?></h1>
    <?php endif; ?>
    
    <div class="cards">
        <?php if (have_posts()) : ?>
            <?php while (have_posts()) : the_post(); ?>
                <article class="card">
                    <a href="<?php the_permalink(); ?>">
                        <div class="card__media">
                            <?php the_post_thumbnail(); ?>
                        </div>
                    
                    <div class="card__content">
                        <h2>
                            <?php the_title(); ?>
                        </h2>
                        <?php the_excerpt(); ?>
                    </div>
                    </a>
                </article>
            <?php endwhile; ?>
        <?php endif; ?>
        <?php wp_reset_query(); ?>
    </div>

</section>

<?php get_footer(); ?>