<?php get_header(); ?>

<?php if (have_posts()) : ?>
    <?php while (have_posts()) : the_post(); ?>
    <section class="hero">
        <div class="wrap">
            <div class="hero__medias">
                <div class="hero__poster">
                    <?php the_post_thumbnail(); ?>
                </div>
                <div class="hero__image">
                    <?php $image = get_field('cw4_film_image'); ?>
                    <?php if ($image): ?>
                        <img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>">
                    <?php endif ?>
                </div>
            </div>
        </div>
    </section>

    <section class="grid section wrap">
        <h1 class="grid__title">
            <?php the_title(); ?>
        </h1>
        <div class="grid__content o-typography">
            <?php the_content(); ?>

            <?php if (get_field('cw4_film_acteurs')): ?>
                <h2>Acteurs</h2>
                <?php the_field('cw4_film_acteurs') ?>
            <?php endif; ?>
        </div>
        <div class="grid__sidebar o-typography">
            <h3>Ma note</h3>
            <p>
                <?php the_field('cw4_film_note') ?>
                ⭐
            </p>

            <?php 
                $realisateur = get_field('cw4_film_realisateur');

                if ($realisateur):
            ?>
                <h3>Réalisateur</h3>
                <p><?php echo get_the_title($realisateur->ID); ?></p>
            <?php endif ?>
            
            <h3>Date de sortie</h3>
            <p><?php the_date(); ?></p>

            <h3>Genre</h3>
            <?php $categories = array(); ?>
            <?php foreach( get_the_category() as $category ): ?>
                <?php array_push($categories, $category->name); ?>
            <?php endforeach?>
            <p><?php echo implode(', ', $categories); ?></p>
        </div>
    </section>

    <!-- Bloc galerie d'image -->/
    <section class="section o-typography">
        <h2 class="wrap">Images</h2>
        
        <div class="swiper-container" data-component="galerie">
            <div class="swiper-wrapper">
                <!-- Slide 1 -->
                <div class="swiper-slide">
                    <img src="<?php bloginfo('template_url') ?>/assets/img1.jpg">
                </div>

                <!-- Slide 2 -->
                <div class="swiper-slide">
                    <img src="<?php bloginfo('template_url') ?>/assets/img2.jpg">
                </div>

                <!-- Slide 3 -->
                <div class="swiper-slide">
                    <img src="<?php bloginfo('template_url') ?>/assets/img3.jpg">
                </div>
            </div>
            <div class="swiper-pagination"></div>
        </div>
    </section>

    <!-- Bloc critique -->
    <section class="section wrap o-typography">
        <h2>Critiques</h2>
        <div class="grid">

            <!-- Critique -->
            <div class="col o-typography">
                <h3>Titre 1</h3>
                <p>Lorem ipsum sit dolor amet c'était écoeurant!</p>
                <p><a class="button" href="https://rottentomatoes.com" target="_blank">Voir la critique complète</a></p>
            </div>
            
            <!-- Critique -->
            <div class="col o-typography">
                <h3>Titre 2</h3>
                <p>Lorem ipsum sit dolor amet c'était correct!</p>
                <p><a class="button" href="https://rottentomatoes.com" target="_blank">Voir la critique complète</a></p>
            </div>
            
            <!-- Critique -->
            <div class="col o-typography">
                <h3>Titre 3</h3>
                <p>Lorem ipsum sit dolor amet c'était vraiment plate!</p>
                <p><a class="button" href="https://rottentomatoes.com" target="_blank">Voir la critique complète</a></p>
            </div>
        </div>
    </section>


    <?php endwhile; ?>
<?php endif; ?>

<?php get_footer(); ?>