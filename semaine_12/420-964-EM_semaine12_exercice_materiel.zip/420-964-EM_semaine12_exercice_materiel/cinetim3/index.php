<?php get_header(); ?>

<section class="section wrap">
    <?php if (have_posts()) : ?>
        <?php while (have_posts()) : the_post(); ?>
            <h1><?php the_title(); ?></h1>
            <?php the_content(); ?>
        <?php endwhile; ?>
    <?php endif; ?>
    
    <div class="cards">
        <?php if (have_posts()) : ?>
            <?php while (have_posts()) : the_post(); ?>
                <article class="card">
                    <a href="<?php the_permalink(); ?>">
                        <div class="card__media">
                            <?php the_post_thumbnail(); ?>
                        </div>
                    </a>
                    <div class="card__content">
                        <h2>
                            <?php the_title(); ?>
                            <span>(<?php echo get_the_date('Y'); ?>)</span>
                        </h2>
                        <?php the_excerpt(); ?>
                    </div>
                </article>
            <?php endwhile; ?>
        <?php endif; ?>
        <?php wp_reset_query(); ?>
    </div>

</section>

<?php get_footer(); ?>